#JAVA_HOME=/usr/jdk/jdk1.6.0_29
#JAVA_HOME=/usr/jdk/jdk1.7.0_04
#export JAVA_HOME

#PATH=/usr/sbin:/usr/bin:.:$JAVA_HOME/bin
#export PATH

java -jar jcredential.jar customer/gui/JCredential
