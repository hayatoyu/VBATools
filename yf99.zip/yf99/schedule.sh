#!/bin/bash
LANG=zh_TW.BIG5
export LANG

#JAVA_HOME=/usr/jdk/jdk1.6.0_29
JAVA_HOME=/usr/jdk/jdk1.7.0_04
export JAVA_HOME

PATH=/usr/sbin:/usr/bin:.:$JAVA_HOME/bin
export PATH

dd="$(date +'%d')"

CLASSPATH=.:jcredential.jar
export CLASSPATH

echo "����w���Ƶ{"
#java -Xms1024M -Xmx1024M customer/main/CredentialSchedule > logs/output_"$dd".log 2>&1
java -Xms1024M -Xmx1024M customer/main/CredentialSchedule
