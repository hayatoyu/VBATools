package customer.main;

import java.util.*;

public class CredentialClient {
	private static CredentialService credentialSvc = CredentialService.getInstance();
	
  public static void main(String[] argv){
    if(argv.length < 1) {
      System.out.println("argument count error!");
      System.exit(1);	
    }
    
    String action = argv[0];
    action = action.replaceAll("-", "").toUpperCase();
    
    String miscs = "";
    if(argv.length > 1) {
    	for(int idx=1;idx<argv.length;idx++) {
    		if(miscs.length() != 0) {
    			miscs += ",";
    		}	
    		miscs += argv[idx];
    	}	
    }	
    
    Locale locale = Locale.getDefault();
    try {
      ResourceBundle resources = ResourceBundle.getBundle("resources.JCredential", locale);
      credentialSvc.setResources(resources);      
      credentialSvc.setLocale(locale);  
    } catch (MissingResourceException mre) {
      System.err.println("resources/JCredential.properties not found");
      System.exit(1);
    }
    
    String combinedMessage = credentialSvc.process(action, miscs);
    
    String[] aMessage = combinedMessage.split("/");
    int rc = Integer.parseInt(aMessage[0]);
    String message = aMessage[1];
    
    System.out.println(message);
         
  }         

}    	